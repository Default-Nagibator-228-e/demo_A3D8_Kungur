Thank you for using our software!

This archive was obtained using the application AlternativaEditor, available at http://editor.alternativaplatform.com/. The archive contains the file 3D-model and texture files needed to display 3D-model with Alternativa3D.

The archive also contains the source code of the demo application on which you can build your application using Alternativa3D.

To build the application, follow these steps:
1. Create a new ActionScript project aimed at Flash Player 11, with the Alternativa3D library attached. Detailed instructions can be found at http://alternativaplatform.com/ru/support/setup/.
2. Copy SimpleViewer.as, MaterialProcessor.as and the model folder from the archive to the root directory of the source code project, make a file SimpleViewer.as as the main application file.
3. Build the project and run the application in Flash Player 11

For technical support contact http://alternativaplatform.com/en/support/.

Official site AlternativaPlatform http://alternativaplatform.com/